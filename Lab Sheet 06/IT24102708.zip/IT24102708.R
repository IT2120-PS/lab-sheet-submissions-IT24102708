getwd()
setwd("C:\\Users\\Bisandi\\Desktop\\3rd Semester\\PS\\Lab Sheet\\Lab 06")

## Question 01 

# i. What is the distribution of X? 
# X has a binomial distribution with n = 50 with p = 0.85

# ii. What is the probability that at least 47 students passed the test? 

pbinom(46, size = 50, prob = 0.85, lower.tail = FALSE)


## Question 02 

# i. What is the random variable(x) for the problem ? 
# The number of customer calls received in an hour.

# ii. What is the distribution of X ?
# Poisson distribution 

# iii. What is the probability that exactly 15 calls are received in an hour ? 

dpois(15, lambda = 12)